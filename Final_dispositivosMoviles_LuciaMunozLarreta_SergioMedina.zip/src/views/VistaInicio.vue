<template>
  <div class="container bienvenidos-container">
    <h1>Bienvenido a mi Aplicación de Planner de Tareas!</h1>
    <p>
      En este espacio, encontrarás una herramienta poderosa para organizarte, planificar y alcanzar tus metas con
      eficacia. Nuestro Planner está diseñado para brindarte la estructura y flexibilidad que necesitas para mantener el
      equilibrio en tu vida cotidiana.
    </p>
    <p>
      Imagina tener una semana organizada de manera óptima, donde cada tarea importante y objetivo esté claramente
      definido. Con nuestro Planner Semanal, podrás visualizar tus compromisos y proyectos, establecer prioridades y
      celebrar tus logros semana tras semana.
    </p>
    <p>Pero eso no es todo, porque nuestro Planner Mensual te permitirá dar un paso atrás y contemplar el panorama
      general. Desde la perspectiva mensual, podrás planificar eventos especiales, citas importantes y fechas límite con
      anticipación, asegurándote de que nada se te escape.</p>
    <p>Además, hemos diseñado este Planner para que se ajuste a tus necesidades y estilo de vida. Puedes personalizarlo
      con colores, pegatinas y anotaciones creativas para hacerlo realmente tuyo.</p>
    <p>Así que, si estás listo para conquistar tus metas, simplificar tu vida y disfrutar de un sentido de logro
      constante, ¡comienza tu viaje organizado con nuestro Planner Semanal y Mensual ahora mismo!</p>
    <p>Recuerda: Un plan bien trazado es el primer paso hacia el éxito. ¡Empieza a planificar, y el mundo será tuyo!</p>


  </div>
</template>
  
<script>
export default {
  name: 'VistaInicio',
};
</script>
  
<style>
.bienvenidos-container {

  margin:  auto;
  padding: 30px;
  background-color: #d8d8e2;

}

h1 {
  text-align: center;
  padding-bottom: 10px;
}

.btn {
  margin-top: 10px;
}
</style>